import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import os
import json
import urllib.parse
import re
import time
import random
from datetime import datetime
import sys

# Addon Setup
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PROFILE = xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}/')
PLAYLIST_DIR = xbmcvfs.translatePath('special://profile/playlists/video/')
CONFIG_FILE = os.path.join(ADDON_PROFILE, 'folder_sets.json')
TAGS_FILE = os.path.join(ADDON_PROFILE, 'tags.json')

def log(msg: str, level: int = xbmc.LOGINFO) -> None:
    xbmc.log(f"[{ADDON_ID}] {msg}", level)

def notify(message: str, error: bool = False) -> None:
    """Handle notifications based on operation mode"""
    mode = ADDON.getSetting('operation_mode')
    if mode == "Foreground" or (error and ADDON.getSetting('enable_error_popups') == 'true'):
        xbmcgui.Dialog().notification(ADDON_NAME, message, xbmcgui.NOTIFICATION_ERROR if error else xbmcgui.NOTIFICATION_INFO)
    elif mode == "Background Notify" and not error:
        xbmc.executebuiltin(f'Notification({ADDON_NAME}, {message})')

def get_setting(setting_id, default=''):
    return ADDON.getSetting(setting_id) or default

def set_setting(setting_id, value):
    ADDON.setSetting(setting_id, str(value))

def apply_set_settings(set_name):
    """Apply settings from a saved set including scan-as tags"""
    sets = load_json(CONFIG_FILE) or {}
    if set_name not in sets:
        log(f"Set not found: {set_name}", xbmc.LOGERROR)
        return False
        
    settings = sets[set_name].get('settings', {})
    
    # Settings whitelist (per-set adjustable)
    settable_keys = {
        # File Selection
        'file_extensions', 'exclude_pattern', 'exclude_folders',
        'min_file_size', 'recursive_scan',
        
        # Sorting
        'folder_sort_mode', 'file_sort_mode', 'custom_folder_order',
        'newest_files', 'limit_mode', 'file_count', 'total_file_count',
        
        # Tagging
        'scan_as', 'tags',
        
        # Display
        'show_folder_names', 'show_metadata', 'show_duration'
    }
    
    # Apply scan-as tags first (if present)
    if 'scan_as' in settings:
        scan_type = settings['scan_as']
        set_setting('scan_as', scan_type)
        _apply_scan_preset(scan_type)
        
    # Apply remaining settings
    applied = 0
    for key, value in settings.items():
        if key in settable_keys and key != 'scan_as':  # Already handled
            set_setting(key, value)
            applied += 1
            
    return applied > 0 or 'scan_as' in settings

def _apply_scan_preset(scan_type):
    """Apply predefined settings based on scan type"""
    presets = {
        '0': {'file_extensions': '.mp4,.mkv,.avi', 'show_metadata': 'true'},  # Regular Files
        '1': {'file_extensions': '.mp4,.mkv', 'show_duration': 'true'},       # YouTube Videos
        '2': {'file_extensions': '.mp4', 'limit_mode': '1', 'total_file_count': '50'},  # Shorts
        '3': {'file_extensions': '.mp4,.mkv,.mp3', 'show_metadata': 'true'}, # Music Videos
        '4': {'exclude_pattern': 'sample,trailer', 'show_folder_names': 'false'}  # Adult
    }
    
    if scan_type in presets:
        for key, value in presets[scan_type].items():
            set_setting(key, value)

def clean_display_name(path):
    try:
        decoded_path = urllib.parse.unquote(path)
        if any(path.startswith(p) for p in ('smb://', 'dav://', 'davs://', 'http://', 'nfs://')):
            basename = os.path.basename(decoded_path)
            return basename.split('?')[0]
        return os.path.basename(decoded_path)
    except:
        return os.path.basename(path)

def format_display_entry(filepath):
    name = os.path.splitext(clean_display_name(filepath))[0]
    
    if get_setting('show_metadata') == 'true':
        clean_name = urllib.parse.unquote(name)
        if year_match := re.search(r'\((\d{4})\)', clean_name):
            name += f" [COLOR gray]({year_match.group(1)})[/COLOR]"
        if res_match := re.search(r'(\d{3,4}[pP]|4[kK])', clean_name):
            name += f" [COLOR blue]{res_match.group(1)}[/COLOR]"
        if get_setting('show_duration') == 'true':
            duration = get_file_duration(filepath)
            if duration > 0:
                mins = duration // 60
                secs = duration % 60
                name += f" [COLOR yellow]{mins}:{secs:02d}[/COLOR]"
    
    if get_setting('show_folder_names') == 'true':
        folder = os.path.basename(os.path.dirname(filepath))
        folder = urllib.parse.unquote(folder)
        return f"[COLOR green]{folder}[/COLOR] {name}"
    return name

def get_file_duration(filepath):
    try:
        if filepath.startswith('special://') or not xbmcvfs.exists(filepath):
            return 0
        item = xbmcgui.ListItem(path=filepath)
        info = xbmc.getInfoLabel(item.getDuration())
        return int(float(info)) if info.isdigit() else 0
    except:
        return 0

def get_media_files(folder, depth=0):
    """Fixed version of get_media_files that doesn't use self references"""
    extensions = [ext.strip().lower() for ext in get_setting('file_extensions', '.mp4,.mkv,.avi,.mov,.wmv').split(',')]
    exclude = [word.strip().lower() for word in get_setting('exclude_pattern', 'sample,trailer').split(',') if word.strip()]
    exclude_folders = [f.strip().lower() for f in get_setting('exclude_folders', '').split(',') if f.strip()]
    min_size = int(get_setting('min_file_size', '50')) * 1024 * 1024
    max_size = int(get_setting('max_file_size', '0')) * 1024 * 1024 if get_setting('enable_max_size') == 'true' else 0
    files = []
    try:
        dirs, filenames = xbmcvfs.listdir(folder)
        
        # Process files in batches
        BATCH_SIZE = 50  # Reduced memory footprint
        for i in range(0, len(filenames), BATCH_SIZE):
            batch = filenames[i:i+BATCH_SIZE]
            for filename in batch:
                # Exit check
                if xbmc.Monitor().abortRequested():
                    return []
                    
                filepath = os.path.join(folder, filename)
                if _is_valid_file(filepath, extensions, exclude, min_size, max_size):
                    files.append(filepath)
                    
                    # Check if we've reached file limit
                    limit_mode = get_setting('limit_mode', '0')
                    if limit_mode == '1':
                        total_limit = int(get_setting('total_file_count', '100'))
                        if len(files) >= total_limit:
                            return files
        
        # Recursive scan with depth control
        if depth < 3 and get_setting('recursive_scan') == 'true':  # Reduced max depth
            for dir in dirs:
                dir_lower = dir.lower()
                if xbmc.Monitor().abortRequested():
                    break
                if dir_lower not in exclude_folders:
                    files.extend(get_media_files(os.path.join(folder, dir), depth+1))
                
    except Exception as e:
        log(f"Scan error: {str(e)}", xbmc.LOGERROR)
        
    return files

def _is_valid_file(filepath, extensions, exclude, min_size, max_size):
    """Check if a file meets all criteria"""
    file_lower = filepath.lower()
    
    # Extension check first (lightweight)
    if not any(file_lower.endswith(ext) for ext in extensions):
        return False
        
    # Size checks
    try:
        stat = xbmcvfs.Stat(filepath)
        file_size = stat.st_size()
        if file_size < min_size:
            return False
        if max_size > 0 and file_size > max_size:
            return False
    except:
        return False
        
    # Pattern checks
    if any(word in file_lower for word in exclude):
        return False
        
    return True

def background_scan(folders):
    """Scan folders without GUI and return file count"""
    total_files = 0
    try:
        for folder in folders:
            files = get_media_files(folder)
            total_files += len(files)
    except Exception as e:
        log(f"Background scan failed: {str(e)}", xbmc.LOGERROR)
    return total_files

def quick_scan():
    """New function for background scanning"""
    dialog = xbmcgui.Dialog()
    folders = select_folders()
    if not folders:
        return
    
    # Show scanning notification
    xbmcgui.Dialog().notification(
        ADDON_NAME, 
        "Scanning folders...", 
        xbmcgui.NOTIFICATION_INFO,
        sound=False
    )
    
    # Perform background scan
    file_count = background_scan(folders)
    
    # Show results
    dialog.notification(
        ADDON_NAME,
        f"Found {file_count} media files",
        xbmcgui.NOTIFICATION_INFO,
        5000  # Show for 5 seconds
    )

def get_folder_sort_key(folder_path):
    """Generate sort key based on folder sorting settings"""
    folder_mode = get_setting('folder_sort_mode', '0')
    custom_order = [f.strip().lower() for f in get_setting('custom_folder_order', '').split(',') if f.strip()]
    folder_name = os.path.basename(folder_path).lower()
    
    if folder_mode == '1':  # A-Z
        return (0, folder_name)
    elif folder_mode == '2':  # Z-A
        return (0, folder_name)
    elif folder_mode == '3' and custom_order:  # Custom
        try:
            return (custom_order.index(folder_name), folder_name)
        except ValueError:
            return (len(custom_order), folder_name)
    else:  # None
        return (0, folder_path)

def apply_sorting(files):
    """Apply all sorting rules to files"""
    # First apply folder sorting
    folder_groups = {}
    for file in files:
        folder = os.path.dirname(file)
        if folder not in folder_groups:
            folder_groups[folder] = []
        folder_groups[folder].append(file)
    
    # Sort folders
    sorted_folders = sorted(folder_groups.keys(), key=get_folder_sort_key)
    
    # Then apply file sorting within folders
    result = []
    file_sort_mode = get_setting('file_sort_mode', '0')
    
    for folder in sorted_folders:
        folder_files = folder_groups[folder]
        
        if file_sort_mode == '1':  # A-Z
            folder_files.sort(key=lambda x: x.lower())
        elif file_sort_mode == '2':  # Z-A
            folder_files.sort(key=lambda x: x.lower(), reverse=True)
        elif file_sort_mode == '3':  # Random
            random.shuffle(folder_files)
        elif file_sort_mode == '4':  # File Size (Smallest first)
            folder_files.sort(key=lambda x: xbmcvfs.Stat(x).st_size())
        elif file_sort_mode == '5':  # File Size (Largest first)
            folder_files.sort(key=lambda x: xbmcvfs.Stat(x).st_size(), reverse=True)
        elif file_sort_mode == '6':  # Duration (Shortest first)
            folder_files.sort(key=lambda x: get_file_duration(x))
        elif file_sort_mode == '7':  # Duration (Longest first)
            folder_files.sort(key=lambda x: get_file_duration(x), reverse=True)
        else:  # Newest first (default)
            folder_files.sort(key=lambda x: xbmcvfs.Stat(x).st_mtime(), reverse=True)
        
        result.extend(folder_files)
    
    # Apply newest files to top if enabled
    newest_count = int(get_setting('newest_files', '0'))
    if newest_count > 0:
        newest = sorted(result, key=lambda x: xbmcvfs.Stat(x).st_mtime(), reverse=True)[:newest_count]
        remaining = [f for f in result if f not in newest]
        result = newest + remaining
    
    return result

def select_folders():
    dialog = xbmcgui.Dialog()
    folders = []
    path = xbmcvfs.translatePath('special://video/')
    
    folder = dialog.browse(0, "Select First Folder (Cancel to abort)", 'files', defaultt=path)
    if not folder:
        return None
        
    folders.append(folder)
    
    while dialog.yesno(ADDON_NAME, "Add another folder?", nolabel="No", yeslabel="Yes"):
        folder = dialog.browse(0, "Select Additional Folder", 'files', defaultt=path)
        if folder and folder not in folders:
            folders.append(folder)
        elif folder:
            dialog.notification(ADDON_NAME, "Folder already added", xbmcgui.NOTIFICATION_WARNING)
    
    return folders

def create_backup(playlist_path):
    backup_dir = os.path.join(PLAYLIST_DIR, "backups")
    if not xbmcvfs.exists(backup_dir):
        xbmcvfs.mkdirs(backup_dir)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_file = f"{os.path.basename(playlist_path)}.bak.{timestamp}"
    backup_path = os.path.join(backup_dir, backup_file)
    xbmcvfs.copy(playlist_path, backup_path)
    
    # Clean up old backups if needed
    max_backups = int(get_setting('max_backups', '3'))
    if max_backups > 0:
        try:
            _, files = xbmcvfs.listdir(backup_dir)
            base_name = os.path.basename(playlist_path)
            matching_backups = [f for f in files if f.startswith(f"{base_name}.bak.")]
            matching_backups.sort(reverse=True)  # Newest first
            
            for old_backup in matching_backups[max_backups:]:
                xbmcvfs.delete(os.path.join(backup_dir, old_backup))
        except Exception as e:
            log(f"Backup cleanup error: {str(e)}", xbmc.LOGERROR)

def create_playlist(folders=None, name=None, from_set=False):
    if folders is None:
        folders = select_folders()
        if not folders:
            return False
            
    if name is None:
        name = xbmcgui.Dialog().input("Enter Playlist Name:")
        if not name:
            return False

    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, "Collecting media files...")
    
    all_files = []
    total_folders = len(folders)
    for i, folder in enumerate(folders):
        progress.update(int(i * 100 / total_folders), f"Scanning {os.path.basename(folder)}...")
        files = get_media_files(folder)
        all_files.extend(files)
        
        if progress.iscanceled():
            progress.close()
            return False
    
    # Apply all sorting rules
    progress.update(90, "Applying sorting...")
    all_files = apply_sorting(all_files)
    
    # Apply total limit if enabled
    if get_setting('limit_mode', '0') == '1':
        all_files = all_files[:int(get_setting('total_file_count', '100'))]
    
    progress.update(95, "Creating playlist...")
    
    if not xbmcvfs.exists(PLAYLIST_DIR):
        xbmcvfs.mkdirs(PLAYLIST_DIR)
    
    playlist_path = os.path.join(PLAYLIST_DIR, f"{name}.m3u")
    
    # Create backup if enabled
    if get_setting('enable_backups') == 'true' and xbmcvfs.exists(playlist_path):
        create_backup(playlist_path)
    
    try:
        with xbmcvfs.File(playlist_path, 'w') as f:
            f.write("#EXTM3U\n")
            for file in all_files:
                f.write(f"#EXTINF:-1,{format_display_entry(file)}\n")
                f.write(f"{file}\n")
        
        progress.close()
        
        # If not from a preset, ask to save as set
        if not from_set and xbmcgui.Dialog().yesno(ADDON_NAME, "Playlist created successfully. Save as folder set?"):
            save_folder_set(name, folders)
        else:
            xbmcgui.Dialog().notification(ADDON_NAME, f"Created playlist: {name}", xbmcgui.NOTIFICATION_INFO)
        
        return True
    except Exception as e:
        progress.close()
        log(f"Playlist creation failed: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(ADDON_NAME, "Failed to create playlist", xbmcgui.NOTIFICATION_ERROR)
        return False

def save_folder_set(name, folders):
    """Save folder set with all current settings"""
    sets = load_json(CONFIG_FILE) or {}
    
    # Only save settings that should be per-set
    sets[name] = {
        'folders': folders,
        'timestamp': time.time(),
        'settings': {
            # File Selection
            'file_extensions': get_setting('file_extensions'),
            'exclude_pattern': get_setting('exclude_pattern'),
            'exclude_folders': get_setting('exclude_folders'),
            'min_file_size': get_setting('min_file_size'),
            'recursive_scan': get_setting('recursive_scan'),
            
            # Sorting
            'folder_sort_mode': get_setting('folder_sort_mode'),
            'file_sort_mode': get_setting('file_sort_mode'),
            'custom_folder_order': get_setting('custom_folder_order'),
            'newest_files': get_setting('newest_files'),
            'limit_mode': get_setting('limit_mode'),
            'file_count': get_setting('file_count'),
            'total_file_count': get_setting('total_file_count'),

            # Tagging
            'scan_as': get_setting('scan_as'),
            'tags': get_setting('tags'),
            
            # Display
            'show_folder_names': get_setting('show_folder_names'),
            'show_metadata': get_setting('show_metadata'),
            'show_duration': get_setting('show_duration')
        }
    }
    save_json(sets, CONFIG_FILE)
    xbmcgui.Dialog().notification(ADDON_NAME, f"Saved set: {name}", xbmcgui.NOTIFICATION_INFO)

def apply_set_settings(set_name):
    """Apply settings from a saved set to the addon settings"""
    sets = load_json(CONFIG_FILE) or {}
    if set_name not in sets or 'settings' not in sets[set_name]:
        return False
        
    settings = sets[set_name]['settings']
    
    # Only apply settings that should be changeable per-set
    settable_keys = {
        # File Selection
        'file_extensions',
        'exclude_pattern',
        'exclude_folders',
        'min_file_size',
        'recursive_scan',
        
        # Sorting
        'folder_sort_mode',
        'file_sort_mode', 
        'custom_folder_order',
        'newest_files',
        'limit_mode',
        'file_count',
        'total_file_count',
        
        # Tagging
        'scan_as',
        'tags',
        
        # Display
        'show_folder_names',
        'show_metadata',
        'show_duration'
    }
    
    applied = 0
    for key, value in settings.items():
        if key in settable_keys:
            set_setting(key, value)
            applied += 1
            
    return applied > 0

def create_playlist_from_set(set_name):
    # Get sets from config
    sets = load_json(CONFIG_FILE) or {}
    if set_name not in sets:
        xbmcgui.Dialog().notification(ADDON_NAME, f"Playlist not found: {set_name}", xbmcgui.NOTIFICATION_ERROR)  # Updated text
        return False
    
    # Apply settings from this set
    set_data = sets[set_name]

    # Store current settings to restore later
    original_settings = {}
    for key in set_data.get('settings', {}):
        original_settings[key] = get_setting(key)

    # Apply set-specific settings
    for key, value in set_data.get('settings', {}).items():
        set_setting(key, value)

    folders = set_data['folders']
    result = create_playlist(folders, set_name, from_set=True)

    # Update timestamp
    if result:
        sets[set_name]['timestamp'] = time.time()
        save_json(sets, CONFIG_FILE)

    # Restore original settings
    for key, value in original_settings.items():
        set_setting(key, value)
    return result

def update_all_playlists():  # Renamed from update_all_sets()
    sets = load_json(CONFIG_FILE) or {}
    if not sets:
        xbmcgui.Dialog().notification(ADDON_NAME, "No playlists found", xbmcgui.NOTIFICATION_WARNING)
        return
    
    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, "Updating playlists...")
    
    success = 0
    total = len(sets)
    for i, set_name in enumerate(sets):
        progress.update(int(i * 100 / total), f"Updating {set_name} playlist...")
        if create_playlist_from_set(set_name):
            success += 1
        
        if progress.iscanceled():
            break
    
    progress.close()
    record_update_time()
    
    xbmcgui.Dialog().notification(
        ADDON_NAME, 
        f"Updated {success}/{total} playlists", 
        xbmcgui.NOTIFICATION_INFO if success > 0 else xbmcgui.NOTIFICATION_WARNING
    )
    return success > 0

def manage_sets():
    sets = load_json(CONFIG_FILE) or {}
    dialog = xbmcgui.Dialog()
    
    while True:
        if not sets:
            choices = ["Create New Set", "Back"]
        else:
            choices = list(sets.keys()) + ["Create New Set", "Back"]
            
        choice = dialog.select("Manage Folder Sets", choices)
        
        if choice == -1 or choice == len(choices)-1:  # Back
            break
        elif choice == len(choices)-2:  # Create New
            name = dialog.input("Set Name:")
            if name:
                folders = select_folders()
                if folders:
                    save_folder_set(name, folders)
                    sets = load_json(CONFIG_FILE) or {}
        else:  # Existing set
            set_name = choices[choice]
            action = dialog.select(f"Set: {set_name}", ["Update Now", "Edit Folders", "Edit Settings", "Delete"])
            
            if action == 0:  # Update
                if create_playlist_from_set(set_name):
                    dialog.notification(ADDON_NAME, f"Updated playlist: {set_name}", xbmcgui.NOTIFICATION_INFO)  # Added "playlist"
                
            elif action == 1:  # Edit Folders
                folders = select_folders()
                if folders:
                    sets[set_name]['folders'] = folders
                    save_json(sets, CONFIG_FILE)
            elif action == 2:  # Edit Settings
                # Apply set settings first
                apply_set_settings(set_name)
                # Open settings dialog
                ADDON.openSettings()
                # Save settings back to set
                if dialog.yesno(ADDON_NAME, "Save changes to set settings?"):
                    temp_folders = sets[set_name]['folders']
                    save_folder_set(set_name, temp_folders)
            elif action == 3:  # Delete
                if dialog.yesno("Confirm", f"Delete {set_name}?"):
                    del sets[set_name]
                    save_json(sets, CONFIG_FILE)

def save_json(data, file_path):
    try:
        if not xbmcvfs.exists(ADDON_PROFILE):
            xbmcvfs.mkdirs(ADDON_PROFILE)
        with xbmcvfs.File(file_path, 'w') as f:
            f.write(json.dumps(data, indent=2))
        return True
    except Exception as e:
        log(f"Save failed: {str(e)}", xbmc.LOGERROR)
        return False

def load_json(file_path):
    try:
        if xbmcvfs.exists(file_path):
            with xbmcvfs.File(file_path, 'r') as f:
                content = f.read()
                return json.loads(content)
    except Exception as e:
        log(f"Load failed: {str(e)}", xbmc.LOGERROR)
    return {}

def check_scheduled_updates():
    """Check if scheduled updates should run"""
    if get_setting('enable_timer') != 'true':
        return False
        
    interval = get_setting('update_interval', '1')  # Default daily
    last_update_str = get_setting('last_update', '')
    
    try:
        last_update = datetime.strptime(last_update_str, "%Y-%m-%d %H:%M:%S") if last_update_str else None
    except ValueError:
        last_update = None
        
    now = datetime.now()
    
    if interval == '0':  # Hourly
        return not last_update or (now - last_update).total_seconds() >= 3600
    elif interval == '1':  # Daily
        # Parse update time
        update_time = get_setting('update_time', '03:00')
        hour, minute = map(int, update_time.split(':'))
        
        # Check if it's past update time and we haven't updated today
        today = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
        return not last_update or (now >= today and last_update.date() < now.date())
    elif interval == '2':  # Weekly
        # Update on Sunday at update_time
        update_time = get_setting('update_time', '03:00')
        hour, minute = map(int, update_time.split(':'))
        
        is_sunday = now.weekday() == 6
        past_update_time = now.hour >= hour and now.minute >= minute
        
        if not last_update:
            return is_sunday and past_update_time
        
        days_since_update = (now.date() - last_update.date()).days
        return is_sunday and past_update_time and days_since_update >= 1
    
    return False

def record_update_time():
    """Record the last update time"""
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    set_setting('last_update', now)

def show_timer_settings():
    """Show and manage timer settings"""
    dialog = xbmcgui.Dialog()
    
    # Get current settings
    enable_timer = get_setting('enable_timer') == 'true'
    interval_idx = int(get_setting('update_interval', '1'))
    update_time = get_setting('update_time', '03:00')
    last_update = get_setting('last_update', 'Never')
    
    interval_names = ['Hourly', 'Daily', 'Weekly']
    interval_name = interval_names[interval_idx]
    
    options = [
        f"Enable scheduled updates: {'Yes' if enable_timer else 'No'}",
        f"Update interval: {interval_name}",
        f"Update time: {update_time}",
        f"Last update: {last_update}",
        "Run update now",
        "Back"
    ]
    
    while True:
        choice = dialog.select("Scheduled Updates", options)
        
        if choice == 0:  # Toggle timer
            enable_timer = not enable_timer
            set_setting('enable_timer', 'true' if enable_timer else 'false')
            options[0] = f"Enable scheduled updates: {'Yes' if enable_timer else 'No'}"
            
        elif choice == 1:  # Change interval
            new_idx = dialog.select("Update Interval", interval_names, preselect=interval_idx)
            if new_idx >= 0:
                interval_idx = new_idx
                set_setting('update_interval', str(interval_idx))
                interval_name = interval_names[interval_idx]
                options[1] = f"Update interval: {interval_name}"
                
        elif choice == 2:  # Change time
            current_hour, current_min = map(int, update_time.split(':'))
            new_time = dialog.numeric(2, "Update Time (HH:MM)", update_time)
            if new_time:
                set_setting('update_time', new_time)
                update_time = new_time
                options[2] = f"Update time: {update_time}"
                
        elif choice == 4:  # Run update now
            if update_all_playlists():  # Updated to call renamed function
                last_update = get_setting('last_update', 'Never')
                options[3] = f"Last update: {last_update}"
                
        elif choice == 5 or choice == -1:  # Back
            break

def show_main_menu():
    dialog = xbmcgui.Dialog()
    while True:
        choice = dialog.select(ADDON_NAME, [
            "Create Playlist", 
            "Quick Scan (No Playlist)",
            "Manage Folder Sets",
            "Update All Playlists",  # Changed from "Update All Sets"
            "Scheduled Updates",
            "Settings",
            "Exit"
        ])
        
        if choice == 0:
            create_playlist()
        elif choice == 1:
            quick_scan()
        elif choice == 2:
            manage_sets()
        elif choice == 3:
            update_all_playlists()  # Updated to call renamed function
        elif choice == 4:
            show_timer_settings()
        elif choice == 5:
            ADDON.openSettings()
        elif choice in (6, -1):
            break

# Service function that runs periodically
class PlaylistService:
    def __init__(self):
        self.monitor = xbmc.Monitor()
        self.last_check = time.time()
    
    def run(self):
        """Run service loop"""
        while not self.monitor.abortRequested():
            # Check every 5 minutes
            if self.monitor.waitForAbort(300):
                break
                
            # Check if scheduled update is due
            if check_scheduled_updates():
                log("Running scheduled update")
                update_all_playlists()  # Updated to call renamed function
                
            self.last_check = time.time()

if __name__ == '__main__':
    if not xbmcvfs.exists(ADDON_PROFILE):
        xbmcvfs.mkdirs(ADDON_PROFILE)
    if not xbmcvfs.exists(PLAYLIST_DIR):
        xbmcvfs.mkdirs(PLAYLIST_DIR)
    
    # Check if run as script or service
    if len(sys.argv) > 1 and sys.argv[1] == 'service':
        # Run as service
        service = PlaylistService()
        service.run()
    else:
        # Run as script
        if get_setting('auto_update') == 'true':
            update_all_playlists()  # Updated to call renamed function
        
        show_main_menu()