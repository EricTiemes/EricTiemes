class PlaylistService:
    def __init__(self):
        self.monitor = xbmc.Monitor()
        self.addon = xbmcaddon.Addon()
        self.interval = 300  # 5 minutes
        self.memory_watchdog = MemoryWatchdog(threshold=85)  # 85% RAM usage

    def run(self):
        log("Service started (Optimized Mode)")
        while not self.monitor.abortRequested():
            try:
                if self.memory_watchdog.is_safe():
                    if check_scheduled_updates():
                        self._safe_update()
                else:
                    log("Memory threshold exceeded - skipping scan", xbmc.LOGWARNING)
                    
            except Exception as e:
                log(f"Service error: {str(e)}", xbmc.LOGERROR)
                if self.addon.getSetting('operation_mode') == '0':  # Only show errors in Foreground
                    notify(f"Scan error: {str(e)}", error=True)
            
            if self.monitor.waitForAbort(self.interval):
                break

    def _safe_update(self):
        """Memory-controlled update"""
        try:
            from default import update_all_sets
            update_all_sets(notify=False)
        except MemoryError:
            log("MemoryError - restarting service", xbmc.LOGERROR)
            xbmc.executebuiltin("RestartApp")


class MemoryWatchdog:
    """Tracks memory usage"""
    def __init__(self, threshold=85):
        self.threshold = threshold
        
    def is_safe(self):
        try:
            used_mem = xbmc.getInfoLabel('System.Memory(free.percent)')
            return float(used_mem) < self.threshold
        except:
            return True  # Fail-safe